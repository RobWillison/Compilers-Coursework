extern TAC_BLOCK *optimiseTac(TAC_BLOCK *input);
