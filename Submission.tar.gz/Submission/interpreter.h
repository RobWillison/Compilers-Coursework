extern UNION* intepret_body(NODE *tree, FRAME *enviroment);
extern UNION* intepret(NODE *tree, FRAME *enviroment);
extern UNION* interpret_definition(NODE *tree, FRAME *enviroment);