int times(int n, int d)
{
  return n * d;
}

int main()
{
  return times(3, 2);
}
