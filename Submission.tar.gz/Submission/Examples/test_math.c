int main()
{
    return 8 * 2 - 2;
}
