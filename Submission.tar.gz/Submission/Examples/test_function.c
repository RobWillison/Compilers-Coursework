int test()
{
  return 4;
}

int main()
{
  return test();
}
