int main()
{
    if (1 > 4) {
      return 4;
    } else if (2 > 1) {
      return 3;
    }

    return 8;
}
