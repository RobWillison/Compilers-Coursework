int main()
{
    int y;
    int x = 4;
    y = 4;
    return x + y;
}
