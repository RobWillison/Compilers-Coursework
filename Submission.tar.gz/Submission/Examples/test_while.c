int main()
{
    int x = 0;
    while (x < 5)
    {
      x = x + 1;
    }

    return x;
}
