extern MIPS *optimise(MIPS *input);
