typedef struct TAC_FRAME {
  struct TOKEN *token;
  int prev;
} TAC_FRAME;
